// pages/loading/loading.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    number : '',//接收用户输入框内容
  },

  enter :function(event){
    console.log(event.detail.value)//输入框内容暂时输出在控制台
    //【赋值】：将输入框内容赋值给number
    this.setData({
      number :event.detail.value
    })
  },

  goToPage :function(){
    //使用tabBar的只能使用switchTab跳转
    //详细https://blog.csdn.net/m0_45329584/article/details/97054052
    wx.switchTab({
      url: '/pages/index/index',
      })
  },


  send :function(){
    var that = this
    var num =that.data.number
    wx.request({
      url: 'http://gwgp-xxppw8rebge.n.bdcloudapi.com/codeNotice?skin=1&sign=1&param=432832&phone='+num,
      header:{
        "Content-Type":"application/json;charset=utf-8",
        "X-Bce-Signature":"AppCode/d1e7656219e049229937789d06ef9c4e",
      },
      success:function(res){
        console.log(res)
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})