// pages/index/index.js
var util = require('../../utils/util.js');
//导入util，里面有获取时间函数,对于函数的修改：连接join为- 删除时分秒（ ${[hour, minute, second].map(formatNumber).join(':')）
Page({

  /**
   * 页面的初始数据
   */
  data: {
    Today:"",/*日期 */
    NoteList:[],
    input:""/*新建的笔记数据 */  
  },

  //本地笔记数据，将创建的笔记以列表形式缓存到本地，并在开启页面时显示输出
  //下次启动页面时加载数据【生命周期onLoad函数】(处理：每次刷新页面后，数据记录也随着清除，造成没有原来数据)
  //app.js有缓存api【系统给的】用法：https://www.kancloud.cn/mrxuxu/wexin/804763
  save:function(){
    wx.setStorageSync('NoteList', this.data.NoteList);//将noteList以缓存至本地，key为NoteList
  },
  loadData:function(){//加载数据
    var note = wx.getStorageSync('NoteList');//从小程序缓存中取出key为NoteList的值
    if(note){//如果缓存存在，即有笔记数据则将数据赋值给NoteList(data)
      this.setData({
        NoteList: note
      });
    }
  },

  

  
  AddInput:function(i){
    //获取输入框(新建笔记)处的数据，传递给data变量input
    this.setData({
      input:i.detail.value
    });
  },

  //更新数据模块
  AddData:function(){
    var that = this;
    //使用note获取已有的笔记数据，以便每次更新不丢失原有数据(‘继承’更新)
    var note = this.data.NoteList;
    //更新数据1，对note原数据使用push方法将input的数据写入note列表中,新数据永远在第一个
    note.push({description:this.data.input})
    //更新数据2(更新data处noteList)，将新建笔记处即input处数据保存到列表后，重置input，以便后续添加(处理：添加下一条时上一条的数据要手动删除)
    that.setData({NoteList:note,input:''});
    //输出控制台
    console.log(this.data.NoteList)
    //更新数据3，调用自定义保存函数 保存数据到本地
    this.save();
  },



  //删除模块
  deleteNote:function(e){
    var note = this.data.NoteList;
    var index = e.currentTarget.id;
    //删除数据，同步日志
    note.splice(index,1);//splice的用法：数组/列表名.splice(第n项，带n且从n之后删几个)
    console.log(note);
    //更新数据
    this.setData({
      NoteList:note
    });
    this.save();
  },

  //结束








  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    var today = util.formatTime(new Date());
    //前面有导入，因此这里直接调用函数，传出new Date() 获取时间
    //console.log(today)
    that.setData({
      Today:today
    })


    //同步本地存储日志，同步NoteList历史数据
    this.loadData();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})